document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.getElementById('nav-toggle');
  const mainNav = document.getElementById('main-nav');

  if (!navToggle || !mainNav) return; // Sicherheitscheck

  // Initialzustand: versteckt auf kleinen Bildschirmen (JS-seitig)
  // Wenn das CSS-Team das visuell regelt, ist das fine — hidden ist eine sinnvolle Fallback-Ebene.
  if (window.innerWidth < 768) {
    mainNav.hidden = true;
    navToggle.setAttribute('aria-expanded', 'false');
  } else {
    mainNav.hidden = false;
    navToggle.setAttribute('aria-expanded', 'false');
  }

  // Klick-Handler für Toggle
  navToggle.addEventListener('click', () => {
    const isOpen = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!isOpen));
    // hidden ist das Gegenteil von aria-expanded
    mainNav.hidden = isOpen;
    // optional: fokus auf ersten Link setzen, damit Tastatur-Nutzer die Navigation sehen
    if (!isOpen) {
      const firstLink = mainNav.querySelector('a');
      if (firstLink) firstLink.focus();
    }
  });

  // Escape schließt das Menü (nützlich für Tastatur/Screenreader)
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' || e.key === 'Esc') {
      if (navToggle.getAttribute('aria-expanded') === 'true') {
        navToggle.setAttribute('aria-expanded', 'false');
        mainNav.hidden = true;
        navToggle.focus(); // Fokus zurück auf den Button
      }
    }
  });

  // Bei Resize Zustand anpassen (sicherstellen, dass Desktop immer sichtbar ist)
  window.addEventListener('resize', () => {
    if (window.innerWidth >= 768) {
      mainNav.hidden = false;
      navToggle.setAttribute('aria-expanded', 'false');
    } else {
      mainNav.hidden = true;
      navToggle.setAttribute('aria-expanded', 'false');
    }
  });
});

// Footer and Header loader
document.addEventListener("DOMContentLoaded", function() {
  // Header laden
  fetch("headfoot/header.html")
    .then(res => res.text())
    .then(data => document.getElementById("header").innerHTML = data);

  // Footer laden
  fetch("headfoot/footer.html")
    .then(res => res.text())
    .then(data => document.getElementById("footer").innerHTML = data);
});

const express = require('express');
const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(express.static('public')); // optional, für CSS/JS

app.get('/', (req, res) => {
    res.render('index'); // index.ejs wird gerendert
});

app.listen(port, () => {
    console.log(`Server läuft auf http://localhost:${port}`);
});
